#!/bin/bash

pushd $(dirname $0)
mkdir /lib/modules/$(uname -r)/extra/ipfw
cp ipfw_mod.ko /lib/modules/$(uname -r)/extra/ipfw
depmod -a
cp ipfw /usr/local/sbin/ipfw
mkdir /usr/local/share/man/man8
cp ipfw.8.gz /usr/local/share/man/man8

