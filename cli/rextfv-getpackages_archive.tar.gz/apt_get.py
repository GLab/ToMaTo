#!/usr/bin/python
import subprocess

def need():
	return True

def ident():
	return 'apt_get'

def get_urls(packagelist):
	urlList=[]
	order=[]
	proc_update = subprocess.call(['apt-get','update'])
	proc = subprocess.Popen(['apt-get','install','--print-uris','-y','-qq']+packagelist,stdout=subprocess.PIPE)
	for line in iter(proc.stdout.readline,''):
		l = line.split()
		urlList.append(l[0])
		order.append(l[1])
	return { 'urls':urlList, 'order':order}

def install(filename):
	proc = subprocess.call(['dpkg','-i',filename])
