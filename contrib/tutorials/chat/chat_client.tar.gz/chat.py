#!/usr/bin/python
import socket, thread, time, sys, random
from datetime import datetime

SO_BINDTODEVICE = 25

PORT = 5000

sockets_out = []

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
sock.settimeout(None)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, True)
sock.setsockopt(socket.SOL_SOCKET, SO_BINDTODEVICE, "eth0")
sock.bind(("0.0.0.0", PORT))
  
myuniqueid = str(random.randint(0, 2**32))

def listen():
  while True:
    (msg, src) = sock.recvfrom(1024)
    ip = src[0]
    try:
      uniqueid, seqnum, timestamp, msg = msg.split("|")
      if uniqueid == myuniqueid:
        continue
      timestamp = datetime.fromtimestamp(float(timestamp)).strftime("%X")
      print "%s %s[%s]: %s" % (timestamp, ip, seqnum, msg)
    except:
      print "Broken packet from %s: %s" % (ip, msg)

thread.start_new_thread(listen, ())
    
myseqnum = 0
    
print "Tutorial chat client\nType a line of text to send it to other clients\nPress ctrl-c to close\n"
    
try:
  while True:
    msg = raw_input()
    myseqnum += 1
    sock.sendto("%s|%d|%f|%s" % (myuniqueid, myseqnum, time.time(), msg), ("<broadcast>", PORT))
except KeyboardInterrupt:
  pass
