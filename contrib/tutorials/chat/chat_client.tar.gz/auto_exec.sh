#!/bin/bash

cp $archive_dir/chat.py /usr/bin/chat

chmod +x /usr/bin/chat
