#!/bin/bash

cp $archive_dir/simulation /usr/bin/
chmod +x /usr/bin/simulation
