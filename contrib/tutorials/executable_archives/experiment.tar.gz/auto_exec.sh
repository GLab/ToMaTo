#!/bin/bash


archive_setstatus "Experiments initialized."

sleep 10



for i in {1..100}
 do
	# set a custom status
	archive_setstatus "Executing experiment $i of 100."
	
	# write some stdout
	echo "Experiment $i/100. Time: $(date)"

	# write something into a custom outputfile
	cat /proc/loadavg >> $archive_dir/my_own_output.txt
	date >> $archive_dir/my_own_output.txt
	echo "_____" >> $archive_dir/my_own_output.txt

	sleep 1

done

archive_setstatus "Experiments finished."
